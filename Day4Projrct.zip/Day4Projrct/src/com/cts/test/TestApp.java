package com.cts.test;

import com.cts.dao.BookingDao;
import com.cts.entities.Location;


public class TestApp {
	public static void main(String[] args) {
		BookingDao dao =new BookingDao();
	
		for(Location location:dao.GetLocationByName("CTS"))
		{
		System.out.println(location.getLocationName());
	}
		
		
		/*Location loc=dao.GetLocationByName("CTS58");
		System.out.println(loc.getLocationId());
		*/
		
		
		/*for(Location location:dao.SortLocation())
		{
		System.out.println(dao.InsertLocations());
	}*/
	}

}
