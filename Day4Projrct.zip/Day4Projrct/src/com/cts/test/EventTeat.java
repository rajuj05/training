package com.cts.test;

import static org.junit.Assert.*;
import junit.framework.Assert;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;

import com.cts.dao.BookingDao;
import com.cts.entities.Location;

public class EventTeat {
	private BookingDao dao;

	@Before
	public void setUp() throws Exception {
		dao=new BookingDao();
	}

	@After
	public void tearDown() throws Exception {
	}

	@Test
	public void test() {
		//fail("Not yet implemented");
		
		/*Location location=new Location();
		location.setLocationName("ASV Sun Tech Park");
		assertTrue(dao.InsertLocation(location)>0);*/
		
	/*	assertTrue(dao.InsertLocations());*/
		
		Assert.assertNotNull(dao.GetLocationByName("CTS8"));
		
	}

}
