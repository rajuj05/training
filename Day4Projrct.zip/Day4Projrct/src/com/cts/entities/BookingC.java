package com.cts.entities;

import java.io.Serializable;

import javax.persistence.Embeddable;
import javax.persistence.JoinColumn;
import javax.persistence.OneToOne;

@Embeddable
public class BookingC implements Serializable{
	
	@OneToOne
	@JoinColumn(name="Cust_Id")
	private Customer customer;
	@OneToOne
	@JoinColumn(name="Event_Id")
	private  Event event;

}
