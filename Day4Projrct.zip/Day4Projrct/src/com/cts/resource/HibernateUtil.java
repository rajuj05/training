package com.cts.resource;

import org.hibernate.SessionFactory;
import org.hibernate.cfg.Configuration;

public class HibernateUtil {
	
	public static SessionFactory GetFactory()
	{
		return new Configuration().configure("com/cts/resource/hibernate.cfg.xml").buildSessionFactory();
	}
	

}
