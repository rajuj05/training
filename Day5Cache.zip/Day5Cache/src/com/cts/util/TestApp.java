package com.cts.util;

import org.hibernate.Cache;
import org.hibernate.HibernateException;
import org.hibernate.Session;
import org.hibernate.SessionFactory;

import com.cts.entities.Location;
import com.cts.resource.HibernateUtil;

public class TestApp {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		System.out.println("before method");
		SessionFactory factory=HibernateUtil.getSessionFactory();
		
		Session session=factory.openSession();
		
       session=factory.openSession();
		
		/*Location location=(Location)session.load(Location.class, 2);
		System.out.println("check first level cache before Evict");
		System.out.println("Status of Object"+session.contains(location));
		session.evict(location);
		System.out.println("check first level cache after Evict");
		System.out.println("Status of Object"+session.contains(location));
		Cache cache= factory.getCache();
		System.out.println("check first level cache after Evict");
		
		System.out.println("Status of Object"+cache.containsEntity(Location.class,2));
		//return cache.containsEntity(Location.class, 100) ;
	
		
*/		
		
		
		
		
		
		
		
		
		
		
		
		
		session.beginTransaction();
		try
		{
			Location location=new Location();
			location.setLocationName("MEPZ");
			session.save(location);
			session.getTransaction().commit();
			
		}
		catch(HibernateException hie)
		{
			session.getTransaction().rollback();
		}
		
		
		
		
		
		
		
		session.close();

	}

}
