import java.util.List;

import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.Transaction;


public class CourseDAO {

	public List<Course> listCourses() {
		Session session=null;
		 session = HibernateUtil.getSessionFactory().openSession();
			Transaction trans = session.beginTransaction();
			List<Course> courseList = (List<Course>) session.createQuery("from Course").list();
			
	return courseList;
	}

	public Course getCourse(int cid) {
		Session session=null;
		 session = HibernateUtil.getSessionFactory().openSession();
			Transaction trans = session.beginTransaction();
			Query query = session.createQuery("from Course where id= :id");
        	query.setLong("id", cid);
	        Course c = (Course) query.uniqueResult();
	        return c;
	}


}
