import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Set;
import java.util.logging.Level;
import java.util.logging.Logger;

import org.hibernate.HibernateException;
import org.hibernate.Session;
import org.hibernate.Transaction;


public class Main {
	public static void main(String[] args) throws IOException {
		Logger log = Logger.getLogger("org.hibernate");
	    log.setLevel(Level.OFF);
		System.setProperty("org.apache.commons.logging.Log",
				"org.apache.commons.logging.impl.NoOpLog");
		Set<Course> courseSet=new HashSet<Course>();
		CourseDAO coursedao =new CourseDAO();
		Student student =new Student();
		BufferedReader bf= new BufferedReader(new InputStreamReader(System.in));
		String sname;
		System.out.println("Enter the Student Details");
		System.out.println("Enter the Student name");
		sname=bf.readLine();
		student.setStudentName(sname);
		System.out.println("Course details");
		List<Course> courseList= coursedao.listCourses();
		for(Course c:courseList){
			System.out.println(c.getCourseId()+"-"+c.getCourseName());
		}
		int choice = 0;
		do{
		System.out.println("Enter course id to assign the student");
		int cid= Integer.parseInt(bf.readLine());
		Course c = coursedao.getCourse(cid);
		System.out.println("Do you want to assign another course to student? If yes press 1 Otherwise press 0");
		insertStudent(student,c);
		choice=Integer.parseInt(bf.readLine());
		}while(choice==1);
		
		//System.out.println("asdasd");
		displayCourseListEnrolledByStudents();
	}

	private static void displayCourseListEnrolledByStudents() {
		//fill the code
			
	}

	private static void insertStudent(Student student, Course course) {
		 
		Session session = null;
		try {
       session = HibernateUtil.getSessionFactory().openSession();
		Transaction trans = session.beginTransaction();
		student.getCourses().add(course);
		session.save(student);
		trans.commit();
		session.close();
		} catch (HibernateException e) {
			e.printStackTrace();
			session.beginTransaction().rollback();
		}
		
		
		
		
			
			
	}

	
}
