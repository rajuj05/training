
public class Address {
	private int id;
	private String addressLine1;
	private String zipcode;
	private String city;
	
	
	public Address(int id, String addressLine1, String zipcode, String city) {
		super();
		this.id = id;
		this.addressLine1 = addressLine1;
		this.zipcode = zipcode;
		this.city = city;
	}
	public Address(){

	}
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getAddressLine1() {
		return addressLine1;
	}
	public void setAddressLine1(String addressLine1) {
		this.addressLine1 = addressLine1;
	}
	public String getZipcode() {
		return zipcode;
	}
	public void setZipcode(String zipcode) {
		this.zipcode = zipcode;
	}
	public String getCity() {
		return city;
	}
	public void setCity(String city) {
		this.city = city;
	}
	
	
	
}
