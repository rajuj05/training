import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.Arrays;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;

import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.Transaction;


public class Main {
	
public static void main(String args[]) throws NumberFormatException, IOException{
	Logger log = Logger.getLogger("org.hibernate");
    log.setLevel(Level.OFF);
	System.setProperty("org.apache.commons.logging.Log",
			"org.apache.commons.logging.impl.NoOpLog");
	getAllEmployees();
	BufferedReader bf= new BufferedReader(new InputStreamReader(System.in));
	Integer eid; 
	System.out.println("Enter the employee id to display the details");
	eid=Integer.parseInt(bf.readLine());
	getEmployeewithID(eid);
	System.out.println("Update Employee's Name");
	System.out.println("Enter the id");
	int id=Integer.parseInt(bf.readLine());
	System.out.println("Enter the employee name");
	String ename=bf.readLine();
	updateEmployee(id,ename);
	System.out.println("After Update");
	getAllEmployees();
    System.out.println("First Five Employees:");
	listOnlyTheFirstFiveEmployees();
	System.out.println("Employee's Address Details");
	listEmployeeDetailsWithAddress();
}


private static void listOnlyTheFirstFiveEmployees() {
	Session session=null;
	session = HibernateUtil.getSessionFactory().openSession();
	//fill the code
       System.out.println(String.format("%-15s%-15s%-15s","Employee Id", "Employee Name","Salary"));
       for(Employee emp : empList){
    	   System.out.println(String.format("%-15s%-15s%-15s",emp.getId(),emp.getName(),emp.getSalary()));
       }
       trans.commit();
	session.close();
	
	
}


private static void getEmployeewithID(int id) {
	
	Session session=null;
	session = HibernateUtil.getSessionFactory().openSession();
	//fill the code
    System.out.println(String.format("%-15s%-15s%-15s","Employee Id", "Employee Name","Salary"));
    System.out.println(String.format("%-15s%-15s%-15s",emp.getId(),emp.getName(),emp.getSalary()));
   
    trans.commit();
    session.close();
	
}


private static void getAllEmployees() {
	Session session=null;
	session = HibernateUtil.getSessionFactory().openSession();
	Transaction trans = session.beginTransaction();
	//fill the code
	 System.out.println(String.format("%-15s%-15s%-15s","Employee Id", "Employee Name","Salary"));
    for(Employee emp : empList){
    	System.out.println(String.format("%-15s%-15s%-15s",emp.getId(),emp.getName(),emp.getSalary()));
	}
    trans.commit();
    session.close();
}         


private static void updateEmployee(int id, String name) {
	Session session=null;
	session = HibernateUtil.getSessionFactory().openSession();
	//fill the code
	//System.out.println("Employee Update Status="+result);
	trans.commit();
session.close();
}


private static void listEmployeeDetailsWithAddress() {
	Session session=null;
	session = HibernateUtil.getSessionFactory().openSession();
	Transaction trans = session.beginTransaction();
	//fill the code
        
    	for(Object[] arr : list){
	            System.out.println(Arrays.toString(arr));
	 }
    	trans.commit();
	session.close();

}

}







