import javax.persistence.*; 
//fill the code
public class ExistingCustomer extends Customer{
	
	
}
