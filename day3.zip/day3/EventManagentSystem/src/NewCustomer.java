import javax.persistence.*;
//fill the code

public class NewCustomer extends Customer{
	

}
