import java.io.Serializable;

import javax.persistence.Embeddable;

@Embeddable
public class BookIssueId implements Serializable {

	private static final long serialVersionUID = 1L;

	private int custId;
	
	private int bookId;

	
	public int getCustId() {
		return custId;
	}

	public void setCustId(int custId) {
		this.custId = custId;
	}

	
	public int getBookId() {
		return bookId;
	}

	public void setBookId(int bookId) {
		this.bookId = bookId;
	}
	
	
}