import java.util.Set;

import javax.persistence.*;



	@Entity
	@Table(name="CUSTOMER")
	public class Customer {

		private int custId;
		
		private String custName;
		
		private Set<BookIssue> bookIssue;
		
		@Id
		@GeneratedValue
		@Column(name="CUSTOMER_ID")
		public int getCustId() {
			return custId;
		}

		public void setCustId(int custId) {
			this.custId = custId;
		}

		@Column(name="CUSTOMER_NAME")
		public String getCustName() {
			return custName;
		}

		public void setCustName(String custName) {
			this.custName = custName;
		}
		
		@OneToMany(fetch=FetchType.EAGER, cascade=CascadeType.ALL)
		public Set<BookIssue> getBookIssue() {
			return bookIssue;
		}

		public void setBookIssue(Set<BookIssue> bookIssue) {
			this.bookIssue = bookIssue;
		}

}
