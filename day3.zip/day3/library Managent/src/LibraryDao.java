import java.util.Date;
import java.util.Iterator;
import java.util.List;
import org.hibernate.HibernateException;
import org.hibernate.Query;
import org.hibernate.Session;


public class LibraryDao {
	public void totalBooksIssued(Date currentDate){
		//fill the code
			System.out.println("Total Books issued for the month " +totalBooks);
		
}
}
