import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.HashSet;
import java.util.TreeSet;
import java.util.Iterator;
import java.util.List;
import java.util.Set;
import java.util.logging.Level;
import java.util.logging.Logger;

import org.hibernate.HibernateException;
import org.hibernate.Session;
import org.hibernate.Transaction;


public class Main {
	public static void main(String[] args) throws IOException {
		Logger log = Logger.getLogger("org.hibernate");
	    log.setLevel(Level.OFF);
		System.setProperty("org.apache.commons.logging.Log",
				"org.apache.commons.logging.impl.NoOpLog");
		
        //System.out.println("Hibernate many to many (XML Mapping)");
        
        BufferedReader br=new BufferedReader(new InputStreamReader(System.in));
        
        Session session = HibernateUtil.getSessionFactory().openSession();
		      
        //System.out.println("Enter 2 employee details");
       /* Employee emp=new Employee();
        emp.setName(br.readLine());
        Employee em=new Employee();
        em.setName(br.readLine());
	*/
		Session session1 = HibernateUtil.getSessionFactory().openSession();
		System.out.println("Session1 open");
		Employee emp1=(Employee)session1.load(Employee.class,new Integer(1));
		System.out.println(emp1.getName());  
		session1.close();  
		System.out.println("Session1 closed");
	
    Session session2=HibernateUtil.getSessionFactory().openSession();
    System.out.println("Session2 open");
    Employee emp2=(Employee)session2.load(Employee.class,new Integer(2)); 
    System.out.println(emp2.getName());  
    session2.close();  
    System.out.println("Session2 closed");
}  
}  