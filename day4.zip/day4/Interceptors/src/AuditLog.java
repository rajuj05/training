import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

@Entity
@Table(name="auditlog")
public class AuditLog {

	private int auditLogId;
	private String action;
	
	private long entityId;
	private String entityName;

	public AuditLog() {
	}

	public AuditLog(String action ,
			long entityId, String entityName) {
		this.action = action;
		
		this.entityId = entityId;
		this.entityName = entityName;
	}

	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	@Column(name = "audit_log_id", unique = true, nullable = false)
	public int getAuditLogId() {
		return this.auditLogId;
	}

	public void setAuditLogId(int auditLogId) {
		this.auditLogId = auditLogId;
	}

	@Column(name = "action", nullable = false, length = 100)
	public String getAction() {
		return this.action;
	}

	public void setAction(String action) {
		this.action = action;
	}

	

	@Column(name = "entity_id", nullable = false)
	public long getEntityId() {
		return this.entityId;
	}

	public void setEntityId(long entityId) {
		this.entityId = entityId;
	}

	@Column(name = "entity_name", nullable = false)
	public String getEntityName() {
		return this.entityName;
	}

	public void setEntityName(String entityName) {
		this.entityName = entityName;
	}
}
