import java.util.Date;
import java.util.Set;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;
import javax.persistence.Transient;

@Entity
@Table(name="orders")
public class Order implements AuditLogInterface{

	@Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "ID", unique = true, nullable = false)
	private int orderId;
	 
	@Column(name="amount")
	private float amount;
	
	@Column(name="orderDate")
	private Date orderDate;
	
	
	public Order(){}
	public Order(float amount,Date orderDate,Customer customer)
	{
		this.amount=amount;
		this.orderDate=orderDate;
		//this.customer=customer;
	}
	public Order(float amount,Date orderDate)
	{
		this.amount=amount;
		this.orderDate=orderDate;
	}
public int getOrderId() {
		return orderId;
	}

	public void setOrderId(int orderId) {
		this.orderId = orderId;
	}

	public Date getOrderDate() {
		return orderDate;
	}

	public void setOrderDate(Date orderDate) {
		this.orderDate = orderDate;
	}

	public float getAmount() {
		return amount;
	}

	public void setAmount(float amount) {
		this.amount = amount;
	}
/*
	public Customer getCustomer() {
		return customer;
	}

	public void setCustomer(Customer customer) {
		this.customer = customer;
	}
*/
	@Transient
	public int getId() {
		return this.orderId;
	}

		
}
