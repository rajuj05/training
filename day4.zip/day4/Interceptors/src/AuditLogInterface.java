
public interface AuditLogInterface {

		public int getId();
	
	

}

