import java.util.ArrayList;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Set;

import org.hibernate.Criteria;
import org.hibernate.criterion.*;
import org.hibernate.HibernateException;
import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.Transaction;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.text.ParseException;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;
import java.util.Date;
import java.text.SimpleDateFormat;
import java.text.ParseException;

public class Main
{
    public static void main(String args[])throws IOException,ParseException
	
	{
		
		Logger log = Logger.getLogger("org.hibernate");
	    log.setLevel(Level.OFF);
		System.setProperty("org.apache.commons.logging.Log",
				"org.apache.commons.logging.impl.NoOpLog");
		
		BufferedReader bf=new BufferedReader(new InputStreamReader(System.in));
    SimpleDateFormat df = new SimpleDateFormat("yyyy-MM-dd"); 
    Customer customer =new Customer();

	CustomerDAO customerdao = new CustomerDAO();
	int custId,orderId;
	int no;
	float amount;
   
	String firstName,lastName,orderDesc;
	Date orderDate;
	
	Set<Order> orderset = new HashSet<Order>();

	System.out.println("Enter the customer details");
	//System.out.println("Customer id :");
	//custId=Integer.parseInt(bf.readLine());
	System.out.println("First name :");
	firstName=bf.readLine();
	System.out.println("Last name :");
	lastName=bf.readLine();
    //customer.setCustId(custId); 
    customer.setfName(firstName);
    customer.setlName(lastName);
	System.out.println("Enter the number of order details");
	no=Integer.parseInt(bf.readLine());
	for(int i=0;i<no;i++)
	{
    Order order =new Order();
    //System.out.println("Order id :");
    //orderId=Integer.parseInt(bf.readLine());
    System.out.println("Amount :");
    amount=Float.parseFloat(bf.readLine());
    System.out.println("Order date :");
	 String dateString = bf.readLine();
	orderDate=df.parse(dateString);
	//order.setOrderId(orderId);
	order.setAmount(amount);
	order.setOrderDate(orderDate);
	
	orderset.add(order);
	}
	//customer.setOrder(orderset);
	customerdao.addDetails(customer,orderset);
	checkAuditLogDetails();
	

}

	private static void checkAuditLogDetails() {
		
		Session session = null;
		Transaction trans=null;
		   session = HibernateUtil.getSessionFactory().withOptions()
	               .interceptor(new AuditLogInterceptor())
	               .openSession();
		
		List<AuditLog> auditLogList;
		try {
			 session = HibernateUtil.getSessionFactory().openSession();
				trans = session.beginTransaction();
				auditLogList = session.createQuery("FROM AuditLog a order by a.entityId,a.entityName").list(); 
					
				System.out.println(String.format("%-15s%-15s%-15s",
						"Action", "Entity Id", "Entity Name"));
				for(AuditLog al :auditLogList){
					System.out.println(String.format("%-15s%-15s%-15s",al.getAction(),al.getEntityId(),al.getEntityName()));
					
				}
				
		trans.commit();
		
		
		} catch (HibernateException e) {
			if (trans!=null) trans.rollback();
			e.printStackTrace();
			System.out.println("Not able to retrieve");
			
		}
		finally
		{
			session.close();
		}
	}
}
