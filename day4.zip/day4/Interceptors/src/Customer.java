import java.util.HashSet;
import java.util.Set;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToMany;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;
import javax.persistence.Transient;

@Entity
@Table(name="customer")
public class Customer  implements AuditLogInterface{

     @Id
	@Column(name="customer_id")
	 @GeneratedValue(strategy = GenerationType.AUTO)
   private int custId;
	 
	 @Column(name="fname")
	 private String fName;
	 
	 @Column(name="lname")
	 private String lName;
	 
	 
	 @OneToMany(cascade=CascadeType.ALL,fetch=FetchType.EAGER)
	 @JoinColumn(name="customer_id")
		private Set<Order> order = new HashSet<Order>();

	public Customer()
	{
		
	}
	public Customer(String fName,String lName)
	{
		this.fName=fName;
		this.lName=lName;
	}
	public Customer(String fName,String lName,Set<Order> order)
	{
		this.fName=fName;
		this.lName=lName;
		this.order=order;
	}
	public Set<Order> getOrder() {
		return order;
	}
	public void setOrder(Set<Order> order) {
		this.order = order;
	}
	public int getCustId() {
		return custId;
	}
	public void setCustId(int custId) {
		this.custId = custId;
	}
	public String getfName() {
		return fName;
	}
	public void setfName(String fName) {
		this.fName = fName;
	}
	public String getlName() {
		return lName;
	}
	public void setlName(String lName) {
		this.lName = lName;
	}
	
	@Transient
	public int getId() {
		return this.custId;
	}
	

}
