import java.util.ArrayList;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Set;

import org.hibernate.Criteria;
import org.hibernate.criterion.*;
import org.hibernate.HibernateException;
import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.Transaction;


import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.text.ParseException;
import java.util.List;

public class ProductDAO {
	public void insertProducts(Product product)
	{
		Session session1=HibernateUtil.getSessionFactory().openSession();
		session1.save(product);
		session1.close();
	}
	
	
	
	public List<Product> displayProducts(){
		Session session = null;
		//Complete the code using Criteria, Criterion and Restrictions API
//fill code here
	
	}
}
