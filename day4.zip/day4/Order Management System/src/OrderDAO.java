import java.util.ArrayList;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Set;

import org.hibernate.Criteria;
import org.hibernate.criterion.*;
import org.hibernate.HibernateException;
import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.Transaction;


import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.text.ParseException;
import java.util.List;

public class OrderDAO {
	
	public void insertOrders(Order order)
	{
		Session session = HibernateUtil.getSessionFactory().openSession();
		session.save(order);
		session.close();
	}

	public void listOrdersForParticularDate(java.util.Date orderDate1){
		Session session = null;
		try{
			session = HibernateUtil.getSessionFactory().openSession();
		//fill code
		}
		catch(HibernateException e){
			System.out.println("Inside exception in the query listOrderforParticularDate"+e.getMessage());
		}
		finally{
			session.close();
		}
	}
}
