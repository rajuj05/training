package com.cognizant.entities;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.DiscriminatorValue;
import javax.persistence.Entity;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;
@Entity
@Table(name="DebitCard")
//@DiscriminatorValue(value="DebitCardObj")
public class DebitCard extends Payment {
	@Column(name="DebitCardNo")
	private long debitCardNo;
	@Column(name="DVV")
	private int dvv;
	@Column(name="D_Name")
	private String dName;
	@Temporal(TemporalType.DATE)
	@Column(name="D_ExpiryDate")
	private Date dExpiryDate;
	
	
	public long getDebitCardNo() {
		return debitCardNo;
	}
	public void setDebitCardNo(long debitCardNo) {
		this.debitCardNo = debitCardNo;
	}
	public int getDvv() {
		return dvv;
	}
	public void setDvv(int dvv) {
		this.dvv = dvv;
	}
	public String getdName() {
		return dName;
	}
	public void setdName(String dName) {
		this.dName = dName;
	}
	public Date getdExpiryDate() {
		return dExpiryDate;
	}
	public void setdExpiryDate(Date dExpiryDate) {
		this.dExpiryDate = dExpiryDate;
	}
	
	

}
