package com.cognizant.test;

import static org.junit.Assert.*;

import java.util.Date;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;

import com.cognizant.dao.DaoManager;
import com.cognizant.entities.CreditCard;
import com.cognizant.entities.DebitCard;
import com.cognizant.entities.Payment;

public class PaymentTest {

	private DaoManager dao;
	@Before
	public void setUp() throws Exception {
		
		 dao=new DaoManager();
	}

	@After
	public void tearDown() throws Exception {
	}

	@Test
	public void PaymentObjtest() {
		//fail("Not yet implemented");
		
		Payment payment=new Payment();
		payment.setAmount(10000);
		payment.setDOT(new Date(2016,6,7));
		assertTrue(dao.AddPayment(payment));
		
	}
	@Test
	public void CreditCardObjtest() {
		//fail("Not yet implemented");
		
		CreditCard payment=new CreditCard();
		payment.setCustomerId(1245);
		payment.setAmount(10000);
		payment.setDOT(new Date(2016,6,7));
		payment.setCreditcardNo(5645545);
		payment.setCvv(555);
		payment.setcExpiryDate(new Date(2017,4,4));
		payment.setcName("Master");
		payment.setEMI(false);
		
		assertTrue(dao.AddPayment(payment));
		
	}
	

	@Test
	public void DebitCardObjtest() {
		//fail("Not yet implemented");
		
		DebitCard payment=new DebitCard();
		payment.setAmount(10000);
		payment.setDOT(new Date(2016,6,7));
		payment.setDebitCardNo(5234564);
		payment.setDvv(455);
		payment.setdName("VISA");
		payment.setdExpiryDate(new Date(2019,5,5));
		assertTrue(dao.AddPayment(payment));
		
	}

}
