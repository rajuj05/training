package com.cognizant.test;

import static org.junit.Assert.*;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;

import com.cognizant.dao.DaoManager;
import com.cognizant.entities.Address;
import com.cognizant.entities.Manager;
import com.cognizant.entities.Person;

public class PersonTest {
	private DaoManager dao;

	@Before
	public void setUp() throws Exception {
		dao=new DaoManager();
	}

	@After
	public void tearDown() throws Exception {
	}

	@Test
	public void test() {
		//fail("Not yet implemented");
		
		Person person=new Person();
		person.setName("Raju");
		Address address=new Address();
		address.setStreetName("Gandhi Street");
		address.setCity("Chennai");
		address.setState("TN");
		assertTrue(dao.AddPerson(person, address));
	}

	
	
	@Test
	public void Managertest() {
		//fail("Not yet implemented");
		
		Manager manager=new Manager();
		
		manager.setName("Raju");
		manager.setAadharCardNo(1234);
		manager.setLocation("Chennai");
		manager.setLeaveApproval(true);
		manager.setNoOfProjects(3);
		manager.setEmployeeNo(12345);
		manager.setProject("Hibernate");
		Address address=new Address();
		address.setStreetName("Gandhi Street");
		address.setCity("Chennai");
		address.setState("TN");
		
		
		
		assertTrue(dao.AddPerson(manager, address));
	}
}
