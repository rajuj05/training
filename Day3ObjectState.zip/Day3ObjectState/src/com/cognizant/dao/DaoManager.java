package com.cognizant.dao;

import org.hibernate.HibernateException;
import org.hibernate.Session;
import org.hibernate.SessionFactory;

import com.cognizant.entities.Address;
import com.cognizant.entities.Payment;
import com.cognizant.entities.Person;
import com.cognizant.resource.HibernateUtil;

public class DaoManager {
	private SessionFactory factory;
	private Session session;
	private boolean status;
	public DaoManager()
	{
		factory=HibernateUtil.GetFactory();
	}
	public boolean AddPayment(Payment payment)
	{
		session=factory.openSession();
		session.beginTransaction();
		try
		{
			session.save(payment);
			session.getTransaction().commit();
			status=true;
		}
		catch(HibernateException hib)
		{
			session.getTransaction().rollback();
		}
		session.close();
		return status;
	}
	
	
	

	public boolean AddPerson(Person person, Address address)
	{
		session=factory.openSession();
		session.beginTransaction();
		try
		{
			session.persist(address);
			person.setAddress(address);
			session.save(person);
			session.getTransaction().commit();
			status=true;
		}
		catch(HibernateException hib)
		{
			session.getTransaction().rollback();
		}
		session.close();
		return status;
	}
	
	public List<Manager> GetAll()
	{
		session=factory.openSession();
		return session.createQuery("from Manager")
	}

/*
	public boolean AddManager(Manager manager, Address address, )
	{
		session=factory.openSession();
		session.beginTransaction();
		try
		{
			session.persist(address);
			person.setAddress(address);
			session.save(person);
			session.getTransaction().commit();
			status=true;
		}
		catch(HibernateException hib)
		{
			session.getTransaction().rollback();
		}
		session.close();
		return status;
	}
*/

}
