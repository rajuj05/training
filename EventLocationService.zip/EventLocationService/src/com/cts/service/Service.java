package com.cts.service;

import javax.ws.rs.Consumes;
import javax.ws.rs.POST;
import javax.ws.rs.Path;
import javax.ws.rs.Produces;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;

import com.cts.dao.BookingDao;
import com.cts.entities.Customer;
import com.cts.entities.Event;
import com.cts.entities.Location;
import com.cts.entities.Message;
@Path("/Service")
public class Service {
	
	@Path("/AddCustomer")
	@POST
	@Consumes({MediaType.APPLICATION_JSON,MediaType.APPLICATION_XML})
	@Produces({MediaType.APPLICATION_JSON,MediaType.APPLICATION_XML})
	public Response AddCustomerService(Customer customer){
		
		boolean status=BookingDao.AddCustomer(customer);
		Message message=new Message();
		message.setStatus("Not Added");
		
		if(status){
			message.setStatus("Record Added");
			
		}
		
		return Response
				 .status(200)
		            .header("Access-Control-Allow-Origin", "*")
		            .header("Access-Control-Allow-Headers", "origin, content-type, accept, authorization")
		            .header("Access-Control-Allow-Credentials", "true")
		            .header("Access-Control-Allow-Methods", "GET, POST, PUT, DELETE, OPTIONS, HEAD")
		            .header("Access-Control-Max-Age", "1209600")
		            .entity(message)
		            .build();
		
	}

	
	
	
	@Path("/AddLocation")
	@POST
	@Consumes({MediaType.APPLICATION_JSON,MediaType.APPLICATION_XML})
	@Produces({MediaType.APPLICATION_JSON,MediaType.APPLICATION_XML})
	public Response AddLocation(Location location){
		
		boolean status=BookingDao.InsertLocations(location);
		Message message=new Message();
		message.setStatus("Location Not Added");
		
		if(status){
			message.setStatus("Location Record Added");
			
		}
		
		return Response
				 .status(200)
		            .header("Access-Control-Allow-Origin", "*")
		            .header("Access-Control-Allow-Headers", "origin, content-type, accept, authorization")
		            .header("Access-Control-Allow-Credentials", "true")
		            .header("Access-Control-Allow-Methods", "GET, POST, PUT, DELETE, OPTIONS, HEAD")
		            .header("Access-Control-Max-Age", "1209600")
		            .entity(message)
		            .build();
		
	}
	
	@Path("/AddEvent")
	@POST
	@Consumes({MediaType.APPLICATION_JSON,MediaType.APPLICATION_XML})
	@Produces({MediaType.APPLICATION_JSON,MediaType.APPLICATION_XML})
	public Response InsertEvent(Event event){
		
		boolean status=BookingDao.InsertEvent(event);
		Message message=new Message();
		message.setStatus("Event Not Added");
		
		if(status){
			message.setStatus("Event Record Added");
			
		}
		
		return Response
				 .status(200)
		            .header("Access-Control-Allow-Origin", "*")
		            .header("Access-Control-Allow-Headers", "origin, content-type, accept, authorization")
		            .header("Access-Control-Allow-Credentials", "true")
		            .header("Access-Control-Allow-Methods", "GET, POST, PUT, DELETE, OPTIONS, HEAD")
		            .header("Access-Control-Max-Age", "1209600")
		            .entity(message)
		            .build();
		
	}

}
