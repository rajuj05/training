package com.cts.dao;

import java.util.List;
import java.util.Random;

import javax.persistence.Query;

import org.hibernate.Cache;
import org.hibernate.Criteria;
import org.hibernate.HibernateException;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.criterion.Restrictions;

import com.cts.entities.Booking;
import com.cts.entities.Customer;
import com.cts.entities.Event;
import com.cts.entities.Location;
import com.cts.resources.HibernateUtil;

public class BookingDao {
private static SessionFactory factory;
private static Session session;
private Location location;
private Event event;
private Customer customer;
public BookingDao()
{
	factory=HibernateUtil.GetFactory();
}


public static boolean AddCustomer (Customer customer){
	
	boolean status=false;
	factory=HibernateUtil.GetFactory();
	session=factory.openSession();
	session.beginTransaction();
	try {
		session.save(customer);
		session.getTransaction().commit();
		status=true;
	} catch (HibernateException e) {
		// TODO Auto-generated catch block
		session.getTransaction().rollback();
	}
	
	return status;
	
	
}

public static boolean InsertLocations(Location location)
{
	boolean status=false;
	factory=HibernateUtil.GetFactory();
	session=factory.openSession();
	session.beginTransaction();
	try {
		session.save(location);
		session.getTransaction().commit();
		status=true;
	} catch (HibernateException e) {
		session.getTransaction().rollback();
		
	}
	return status;
	
}
public static boolean InsertEvent(Event event)
{
	boolean status=false;
	factory=HibernateUtil.GetFactory();
	session=factory.openSession();
	session.beginTransaction();
	try
	{
	session.save(event);
	session.getTransaction().commit();
	}
	catch(HibernateException hib)
	{
		session.getTransaction().rollback();
	}
	session.close();
	
	
	return status;
}




public List<Location > GetLocatonByName(String name){
	
	
	factory=HibernateUtil.GetFactory();
	session=factory.openSession();
	
	/*	org.hibernate.Query query=session.createQuery("from Location where locationName=? ");*/
	
/*	org.hibernate.Query query=session.getNamedQuery("GetLocationByName");*/
	
	
	
	Criteria criteria=session.createCriteria(Location.class);
	criteria.add(Restrictions.gt("locationId", 150));
	criteria.add(Restrictions.like("locationName", "CTS%"));
	
	return criteria.list();
	
	
		/*query.setParameter(0, name);
		return (Location) query.list().get(0);
		
	*/
}


public long GetLocatonCount(){
	
	
	factory=HibernateUtil.GetFactory();
	session=factory.openSession();
		org.hibernate.Query query=session.createQuery("select count(loc.locationName) from Location loc");
		return (long) query.list().get(0);
		
	
}


public int GetMaxLocationId(){
	
	
	factory=HibernateUtil.GetFactory();
	session=factory.openSession();
		org.hibernate.Query query=session.createQuery("select max(loc.locationId) from Location loc");
		return (int) query.list().get(0);
		
	
}

public List<Location> SortLocation(){
	
	
	factory=HibernateUtil.GetFactory();
	session=factory.openSession();
		org.hibernate.Query query=session.createQuery("from Location loc order by loc.locationName asc");
		return query.list();
	
}


public int SecondLastLocation(){

	factory=HibernateUtil.GetFactory();
	session=factory.openSession();
		org.hibernate.Query query=session.createQuery("select max(l.locationId) from Location l where l.locationId"
				+"<(select max (loc.locationId) from Location loc)");
		return (int) query.list().get(0);
	
	
}


public int InsertLocation(Location loc)
{
	location=loc;	
	int pk=0;
	session=factory.openSession();
	session.beginTransaction();
	try
	{
	pk=(Integer) session.save(location);
	
	session.getTransaction().commit();
	}
	catch(HibernateException hib)
	{
		session.getTransaction().rollback();
	}
	session.close();
	return pk;
}





public boolean TestSecondLevelCache(){
	factory=HibernateUtil.GetFactory();
	session=factory.openSession();
	
	Location location=(Location) session.load(Location.class, 100);
	System.out.println("Checking first level Cache");
	System.out.println("Status of Object"+session.contains(location));
	session.evict(location);
	System.out.println("Checking first level Cache after evict");
	System.out.println("Status of Object"+session.contains(location));
	Cache cache= factory.getCache();
	
	System.out.println("Checking second level Cache after evict");
	System.out.println("Status of Object"+cache.containsEntity(Location.class, 100));
	
	return cache.containsEntity(Location.class, 100);
	
	
	
	
	
	
	
	
	
	
	
	
	
}

public void InsertBooking(Booking book)
{
	
}
public void InsertCustomer(Customer cust)
{
	
}
}
