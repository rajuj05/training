import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;

import org.hibernate.HibernateException;
import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.Transaction;
import org.hibernate.SessionFactory;

public class Main {
	static SessionFactory factory;

	public static void main(String args[]) throws IOException{
		Logger log = Logger.getLogger("org.hibernate");
		log.setLevel(Level.OFF);
		System.setProperty("org.apache.commons.logging.Log",
				"org.apache.commons.logging.impl.NoOpLog");
		String name,email,phone;
		BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
		customerList();
		System.out.println("Enter the customer id to be updated");
		int id=Integer.parseInt(br.readLine());
		System.out.println("Enter the email");
		email=br.readLine();
		updateEmail(id,email);
		customerList();	
	}
	public static void updateEmail(int id,String email){
		/*fill code here*/
			}
	
	
	public static void customerList() {

		Session session = null;
		try {

			session = HibernateUtil.getSessionFactory().openSession();

			session.beginTransaction();
			String hql = "from Customer ORDER by id";

			Query query = session.createQuery(hql);

			List<Customer> listCustomer = query.list();

			System.out.println("Customer details are :");
			System.out.println(String.format("%-15s%-15s%-15s%-15s",
					"Customer Id", "Customer Name", "Customer Email",
					"Customer Phone"));

			for (Customer cus : listCustomer) {
				//System.out.println("cus.getPhone()"+cus.getPhone());
System.out.println(String.format("%-15s%-15s%-15s%-15s",cus.getId(), cus.getName(),cus.getEmail(),cus.getPhone()));

			}
			// persisting the object

		} catch (Exception e) {
			System.out.println("exception" + e);
		}

	}
	
	

}
