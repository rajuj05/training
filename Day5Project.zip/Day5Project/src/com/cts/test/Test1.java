package com.cts.test;

import static org.junit.Assert.*;
import junit.framework.Assert;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import com.cts.dao.BookingDao;

public class Test1 {
	private BookingDao dao;

	@Before
	public void setUp() throws Exception {
		dao=new BookingDao();
	}

	@After
	public void tearDown() throws Exception {
	}

	@Test1
	public void test() {
		//fail("Not yet implemented");
		
	}

}
