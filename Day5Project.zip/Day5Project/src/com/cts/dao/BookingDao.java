package com.cts.dao;

import java.util.List;
import java.util.Random;



import org.hibernate.Cache;
import org.hibernate.Criteria;
import org.hibernate.HibernateException;
import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.criterion.Restrictions;

import com.cts.entities.Booking;
import com.cts.entities.Customer;
import com.cts.entities.Event;
import com.cts.entities.Location;
import com.cts.resource.HibernateUtil;

public class BookingDao {
	
	private SessionFactory factory;
	private Session session;
	private Location location;
	private Event event;
	private boolean status;
	private Customer customer;
	
	public BookingDao()
	{
		System.out.println("before factory");
		factory=HibernateUtil.GetFactory();
		System.out.println("After factory ");
	}
	
	
	
	public boolean TestSecondLevelCache()
	{
		factory=HibernateUtil.GetFactory();
		session=factory.openSession();
		
		Location location=(Location)session.load(Location.class, 105);
		System.out.println("check first level cache before Evict");
		System.out.println("Status of Object"+session.contains(location));
		session.evict(location);
		System.out.println("check first level cache after Evict");
		System.out.println("Status of Object"+session.contains(location));
		Cache cache=(Cache) factory.getCache();
		System.out.println("check first level cache after Evict");
		
		System.out.println("Status of Object"+cache.containsEntity(Location.class,100));
		return cache.containsEntity(Location.class, 100) ;
	}
	
	
	
	public boolean InsertLocations()
	{
		boolean status=false;
		factory=HibernateUtil.GetFactory();
		session=factory.openSession();
		session.beginTransaction();
		Random random=new Random(100);
		Location location=null;
		
		
		
		try
		{
			for(int i=0;i<100;i++)
			{
				location =new Location();
				location.setLocationName("CTS"+random.nextInt());
				session.save(location);
				
				if(i%20==0)
				session.flush();
				session.clear();
					
					
			}
			session.getTransaction().commit();
			status=true;
		}
		
		catch(HibernateException hie)
		{
			session.getTransaction().rollback();
		}
		return status;
		
	}
}
	
	
	
	
	
	
	
	
	
	
	
	
	/*
	
	public Location GetLocationByName(String name)
	{
		factory=HibernateUtil.GetFactory();
		session=factory.openSession();
		//Query query=session.createQuery("from Location where locationName=?");
		query.setParameter(1, name);
		return (Location)query.list().get(0);
	}
	
	
	
	public List<Location> GetLocationByName(String name)
	{
		factory=HibernateUtil.GetFactory();
		session=factory.openSession();
		//Query query=session.createQuery("from Location where locationName=?");
		//Query query=session.getNamedQuery(GetLocationByName);
		
		Criteria criteria=session.createCriteria(Location.class);
		criteria.add(Restrictions.gt("location", 150));
		criteria.add(Restrictions.gt("locationName", "CTS%"));
		return criteria.list();
		
		//return (Location)criteria.list().get(0);
		//query.setParameter(1, name);
		//return (Location)query.list().get(0);
	}
	
	public long GetLocationCount()
	{
		factory=HibernateUtil.GetFactory();
		session=factory.openSession();
		Query query=session.createQuery("select Count(loc.locationName)from Location loc");
		return (Long)query.list().get(0);
	}
	
	public long GetMaxLocationId()
	{
		factory=HibernateUtil.GetFactory();
		session=factory.openSession();
		Query query=session.createQuery("select max(loc.locationId)from Location loc");
		return (Long)query.list().get(0);
	}
	public List<Location> SortLocation()
	{
		factory=HibernateUtil.GetFactory();
		session=factory.openSession();
		Query query=session.createQuery("from Location loc order by loc.locationName asc");
		return query.list();
	}
	
	
	
	public boolean InsertLocations()
	{
		boolean status=false;
		factory=HibernateUtil.GetFactory();
		session=factory.openSession();
		session.beginTransaction();
		Random random=new Random(100);
		Location location=null;
		
		
		
		try
		{
			for(int i=0;i<100;i++)
			{
				location =new Location();
				location.setLocationName("CTS"+random.nextInt());
				session.save(location);
				
				if(i%20==0)
				session.flush();
				session.clear();
					
					
			}
			session.getTransaction().commit();
			status=true;
		}
		
		catch(HibernateException hie)
		{
			session.getTransaction().rollback();
		}
		return status;
		
	}
	public int InsertLocation(Location loc)
	{
		location=loc;
		int pk=0;
		session=factory.openSession();
		session.beginTransaction();
		try
		{
			pk=(Integer)session.save(location);
			session.save(location);
			
			
			session.getTransaction().commit();
			
		}
		catch(HibernateException hie)
		{
			session.getTransaction().rollback();
		}
		return pk;
		
	}
	public void InsertEvent(Event eve, int locationId )
	{
		event=eve;
		session=factory.openSession();
		Location result=(Location)session.get(Location.class, locationId);
		session.beginTransaction();
		try
		{
			event.setLocation(result);
			session.persist(event);
			
			session.getTransaction().commit();
			
		}
		catch(HibernateException hie)
		{
			session.getTransaction().rollback();
		}
		
		
	}
	
	public void InsertBooking(Booking book)
	{
		
	}
	public void InsertCustomer(Customer cust)
	{
		
	}

}
*/