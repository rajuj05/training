package com.cognizant.entities;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.OneToOne;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;
import javax.persistence.CascadeType;

import org.hibernate.annotations.Cascade;


@Entity
@Table(name="Book")
public class Book {
	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	@Column(name="Book_ISBN")
	private int isbnNo;
	@Column(name="Book_Name")
	private String bookName;
	@Temporal(TemporalType.DATE)
	@Column(name="Book_DOP")
	private Date DOP;
	@OneToOne(mappedBy="book",cascade=CascadeType.ALL)
	private Author author;
	
	

	public int getIsbn() {
		return isbnNo;
	}

	public void setIsbn(int isbn) {
		this.isbnNo = isbn;
	}

	public String getName() {
		return bookName;
	}

	public void setName(String name) {
		this.bookName = name;
	}

	public Date getDop() {
		return DOP;
	}

	public void setDop(Date dop) {
		this.DOP = DOP;
	}

	public Author getAuthor() {
		return author;
	}

	public void setAuthor(Author author) {
		this.author = author;
	}
	
	

}
