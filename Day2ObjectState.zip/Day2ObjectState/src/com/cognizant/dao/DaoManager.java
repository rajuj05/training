package com.cognizant.dao;

import java.util.List;


import org.hibernate.Query;

import org.hibernate.HibernateException;
import org.hibernate.Session;
import org.hibernate.SessionFactory;

import com.cognizant.entities.Address;
import com.cognizant.entities.Author;
import com.cognizant.entities.Book;
import com.cognizant.entities.Course;
import com.cognizant.entities.Customer;
import com.cognizant.entities.Event;
import com.cognizant.entities.Player;
import com.cognizant.entities.Room;
import com.cognizant.entities.Team;
import com.cognizant.entities.Trainee;
import com.cognizant.resource.HibernateUtil;

public class DaoManager {
	private SessionFactory factory;
	private Session session;
	private boolean status;
	
	public DaoManager()
	{
		factory=HibernateUtil.GetFactory();
	}
	//public boolean AddCustomer_Address(Customer customer, Address address)
	public boolean AddBook_Author(Book book, Author author)
	{
		session=factory.openSession();
		session.beginTransaction();
		
		
		
	
	try
	{
		
		
		author.setBook(book);
		book.setAuthor(author);
		session.save(book);
		session.getTransaction().commit();
		status=true;
		
		/*session.persist(address);
		customer.setAddress(address);
		session.persist(customer);
		session.getTransaction().commit();
		status=true;*/
		
	}
	catch(HibernateException he)
	{
		session.getTransaction().rollback();
		
	}
	session.close();
	return status;
	}
	public boolean AddTeam_Player(Team team, List<Player> playerList)
	{
		session=factory.openSession();
		session.beginTransaction();
		
		
		
	
	try
	{
		
		
	
		team.setPlayerList(playerList);
		session.save(team);
		session.getTransaction().commit();
		status=true;
		
		/*session.persist(address);
		customer.setAddress(address);
		session.persist(customer);
		session.getTransaction().commit();
		status=true;*/
		
	}
	catch(HibernateException he)
	{
		session.getTransaction().rollback();
		
	}
	session.close();
	return status;
	}
	
	/*public Query GetAll()
	{
		session=factory.openSession();
		return (Query) session.createQuery("select cust.customerId, cust.name, addr.street,addr.city from Customer cust inner join cust.address addr");
		
	}*/
	public List<Team> getAllTeam_Player()
	{
		session=factory.openSession();
		return session.createQuery("from Team").list();
		
	}
	
	
	public boolean AddTrainee_Course(List<Trainee> traineeList, List<Course> courseList)
	{
		session=factory.openSession();
		session.beginTransaction();
		
	try
	{
		for(Trainee trainee:traineeList)
		{
			trainee.setCourseList(courseList);
			session.save(trainee);
		}
		
		session.getTransaction().commit();
		status=true;
	
		
		
		
		/*session.persist(address);
		customer.setAddress(address);
		session.persist(customer);
		session.getTransaction().commit();
		status=true;*/
		
	}
	catch(HibernateException he)
	{
		session.getTransaction().rollback();
		
	}
	session.close();
	return status;
	}
	
	public boolean AddEvent_Room(Event event, Room room)
	{
		session=factory.openSession();
		session.beginTransaction();
		
		
		
	
	try
	{
		
		
		room.setEvent(event);
		event.setRoom(room);
		session.save(event);
		session.getTransaction().commit();
		status=true;
		
		/*session.persist(address);
		customer.setAddress(address);
		session.persist(customer);
		session.getTransaction().commit();
		status=true;*/
		
	}
	catch(HibernateException he)
	{
		session.getTransaction().rollback();
		
	}
	session.close();
	return status;
	
	
	}
}


