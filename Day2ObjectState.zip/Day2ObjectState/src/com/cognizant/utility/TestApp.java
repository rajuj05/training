package com.cognizant.utility;

import java.util.ArrayList;
import  java.util.Date;
import java.util.Iterator;
import java.util.List;

import com.cognizant.dao.DaoManager;
import com.cognizant.entities.Address;
import com.cognizant.entities.Author;
import com.cognizant.entities.Book;
import com.cognizant.entities.Course;
import com.cognizant.entities.Customer;
import com.cognizant.entities.Event;
import com.cognizant.entities.Player;
import com.cognizant.entities.Team;
import com.cognizant.entities.Trainee;

public class TestApp {
	public static void main(String[] args) {
		DaoManager dao=new DaoManager();
		
		
		Event event=new Event();
		event.setEventName("java");
		
		Author author=new Author();
		author.setAuthorName("Gosling");
		dao.AddBook_Author(book, author);
	
		/*List<Trainee> traineeList=new ArrayList<Trainee>();
		List<Course> courseList=new ArrayList<Course>();
		
		Trainee trainee=new Trainee();
		trainee.setTraineeNaem("sanjay");
		traineeList.add(trainee);
		trainee=new Trainee();
		trainee.setTraineeNaem("Sudha");
		traineeList.add(trainee);
		trainee=new Trainee();
		trainee.setTraineeNaem("Ananya");
		traineeList.add(trainee);
		
		Course course=new Course();
		course.setCourseName("Hibernate");
		course.setTraineeList(traineeList);
		courseList.add(course);
		dao.AddTrainee_Course(traineeList, courseList);*/
		
		
		/*for(Team team:dao.getAllTeam_Player())
		{
			System.out.println(team.getTeamName());
			for(Player player:team.getPlayerList())
			{
				System.out.println(player.getPlayName());
			}
		}*/
		
		
		/*Team team=new Team();
		
		team.setTeamName("Rc");
		List<Player> playerList=new ArrayList<Player>();
		Player player=new Player();
		player.setPlayName("Yuvi");
		player.setTeam(team);
		playerList.add(player);
		player=new Player();
		player.setPlayName("Kumar");
		player.setTeam(team);
		playerList.add(player);
		player=new Player();
		player.setPlayName("Rahul");
		player.setTeam(team);
		playerList.add(player);
		dao.AddTeam_Player(team, playerList);*/
		
		
		/*Book book=new Book();
		book.setName("java");
		book.setDop(new Date(97,1,1));
		Author author=new Author();
		author.setAuthorName("Gosling");
		dao.AddBook_Author(book, author);*/
		
		
		
		/*Iterator itr=dao.GetAll().iterate();
		System.out.println("CustomerId"+"\t"+"Name"+"\t"+"Street"+"\t"+"City");
		while(itr.hasNext())
		{
			Object[] obj=(Object[])itr.next();
			System.out.println(obj[0]+"\t"+obj[1]+"\t"+obj[2]+"\t"+obj[3]);
		}*/
		
		
		
		
		/*Address address=new Address();
		address.setStreet("Rajaji Street");
		address.setCity("Chennai");
		Customer customer=new Customer();
		customer.setName("Raju");
		customer.setDob(new Date(1999,5,8));
		dao.AddCustomer_Address(customer, address);*/
		
		
	}

}
