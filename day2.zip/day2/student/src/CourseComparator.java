import java.util.*;
public class CourseComparator implements Comparator<Course> {

	public int compare(Course e1, Course e2) {
        return e1.getCourseName().compareTo(e2.getCourseName());
	}
	
}
