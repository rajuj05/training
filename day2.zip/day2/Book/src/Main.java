import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.text.ParseException;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;


public class Main {
static BufferedReader bf=new BufferedReader(new InputStreamReader(System.in));
public static void main(String[] args)throws IOException, ParseException
{
	Logger log = Logger.getLogger("org.hibernate");
	log.setLevel(Level.OFF);
	System.setProperty("org.apache.commons.logging.Log",
			"org.apache.commons.logging.impl.NoOpLog");
	BookDAO bookdao= new BookDAO();
	int id;
	String name,category;
	System.out.println("Enter the book details");
	Book book =new Book();
	System.out.println("Enter the name of the book");

	name=bf.readLine();
	System.out.println("Enter the category of the book");

	category=bf.readLine();
	

	book.setName(name);

	book.setCategory(category);
	bookdao.addDetails(book);
	List<Book> booklist = bookdao.listDetails();
	for(int i=0;i<booklist.size();i++)
	{
		System.out.print(booklist.get(i).getId()+"-");
		System.out.print(booklist.get(i).getName()+"-");
		System.out.println(booklist.get(i).getCategory());

	}
}
}

