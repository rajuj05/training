package com.cognizant.dao;

import java.util.List;

import javax.transaction.Status;

import org.hibernate.HibernateException;
import org.hibernate.Session;
import org.hibernate.SessionFactory;

import com.cognizant.entities.Room;
import com.cognizant.resource.HibernateUtil;

public class RoomManager {
	
	private SessionFactory factory;
	private Session session;
	
	public RoomManager()
	{
		super();
		factory=HibernateUtil.GetFactory();
		
	}
	
	public boolean AddRoom(Room room)
	{
		boolean status=false;
		
		session =factory.openSession();
		session.beginTransaction();
		try
		{
			session.save(room);
			session.getTransaction().commit();
		}
		catch(HibernateException ex)
		{
			session.getTransaction().rollback();
		}
		return status;
		
	}
	
	public List<Room> GetAllRooms()
	{
		session=factory.openSession();
		return session.createQuery("from Room").list();
	}
	
	
	public boolean UpdateRoom(int roomNo)
	{
		boolean status=false;
		session=factory.openSession();
		Room room=(Room)session.get(Room.class, roomNo);
		room.setCapacity(45);
		room.setSystem_Avl(false);
		session.beginTransaction();
		try
		{
			//session.update(room);
			session.getTransaction().commit();
			status=true;
			
		}
		catch(HibernateException he)
		{
			
			session.getTransaction().rollback();
		}
		session.close();
		return status;
				
	}
	
	public boolean DeleteRoom(int roomNo)
	{
		boolean status=false;
		session=factory.openSession();
		Room room=(Room)session.get(Room.class, roomNo);
		
		
		/*room.setCapacity(55);
		room.setSystem_Avl(false);*/
		
		
		session.beginTransaction();
		try
		{
			session.update(room);
			session.getTransaction().commit();
			status=true;
			
		}
		catch(HibernateException he)
		{
			
			session.getTransaction().rollback();
		}
		session.close();
		return status;
		
	}
	
	public boolean roomEvict_clear(int roomNo1, int roomNo2)
	{
		boolean status=false;
		session=factory.openSession();
		Room obj1=(Room)session.get(Room.class, roomNo1);
		Room obj2=(Room)session.get(Room.class, roomNo2);
		//modify object1 and object2
		//session.evict(obj2);//object2 detached from the session
		session.clear();
		
		session.beginTransaction();
		obj1.setCapacity(75);
		obj2.setCapacity(100);
		session.getTransaction().commit();
		session.close();
		
		status=true;
		return status;
	}
	
	
	public boolean SessionClose(int roomNo)
	{
		boolean status=false;
		session=factory.openSession();
		Room room=(Room)session.get(Room.class, roomNo);
		session.beginTransaction();
		session.close();
		
		room.setCapacity(67);
		
		Session session1=factory.openSession();
		session1.beginTransaction();
		Room room1=(Room)session1.get(Room.class, roomNo);
		session1.merge(room);
		
				
		session1.getTransaction().commit();
		status=true;
		return status;
		
	}

}
