package com.cognizant.utilities;

import java.util.Scanner;

import com.cognizant.dao.EventManager;
import com.cognizant.dao.RoomManager;
import com.cognizant.entities.Event;
import com.cognizant.entities.EventKey;
import com.cognizant.entities.Room;

public class TestApp {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		EventManager eventmanager=new EventManager();
		EventKey eventkey=new EventKey();
		eventkey.setEventId(1);
		eventkey.setTrainerId(249);
		Event event=new Event();
		event.setEventid(eventkey);
		event.setDuration(5);
		event.setLocation("Chennai");
		event.setEventName("Hibernate training");
		eventmanager.AddEvent(event);
		
		
		
		

		/*RoomManager roomManager=new RoomManager();
		Room room = new Room();
		room.setCapacity(25);
		room.setLocation("ASV Sun Tech");
		room.setProjector_Avl(true);
		room.setSystem_Avl(true);
		if(roomManager.AddRoom(room));
		System.out.println("Record Added");
		
		
		for(Room room:roomManager.GetAllRooms())
		{
			System.out.println(room.getRoomNo());
			System.out.println(room.getCapacity());
			
			
		}
		
		Scanner scanner =new Scanner(System.in);
		System.out.println("Enter Room No");
		
		int roomNo1=scanner.nextInt();
		System.out.println("Enter Room No");
		int roomNo2=scanner.nextInt();
		
		//roomManager.UpdateRoom(2);
		//roomManager.DeleteRoom(roomNo);
		
		roomManager.roomEvict_clear(roomNo1, roomNo2);
		
		int roomNo1=scanner.nextInt();
		roomManager.SessionClose(roomNo1);*/
	}

}
